#! /bin/sh
# This is a generated file.
. E:/cocos2d/open_tools/pcre2_10_32/RunTest
if test "$?" != "0"; then exit 1; fi
# End
